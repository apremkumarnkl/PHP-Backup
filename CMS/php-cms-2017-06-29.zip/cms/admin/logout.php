<?php
define('pageclassconst', TRUE);
include_once './login/loginClass.php';
$login=new loginClass();
$login->logout();